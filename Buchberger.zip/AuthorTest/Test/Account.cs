﻿using System;
using System.Collections;
using Attributes;

namespace Test
{
    [Author("Your Name")]
    class Account
    {
        private ArrayList _orders = new ArrayList();
     
        [IsTested()]
        public void AddOrder(Order orderToAdd)
        {
            _orders.Add(orderToAdd);
        }

        public ArrayList GetOrders()
        {
            return _orders;
        }
    }
}
