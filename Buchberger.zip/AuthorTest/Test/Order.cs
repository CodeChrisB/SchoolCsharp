﻿using System;
using Attributes;

namespace Test
{
    [Author("Your Name", Version = "2"), IsTested()]
    class Order
    {
    }
}
